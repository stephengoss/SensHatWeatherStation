class Config:
    # Weather Underground
    STATION_ID = ""
    STATION_KEY = ""
